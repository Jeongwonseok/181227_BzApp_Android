package com.example.jws.bzapp;

public class FranchiseInfo {
    String name, Storesu, Ownermoney, Asales17, Interior, Category;

    FranchiseInfo(String name, String Storesu, String Ownermoney, String Asales17, String Interior, String Category) {
        this.name = name;
        this.Storesu = Storesu;
        this.Ownermoney = Ownermoney;
        this.Asales17 = Asales17;
        this.Interior = Interior;
        this.Category = Category;
    }
}
