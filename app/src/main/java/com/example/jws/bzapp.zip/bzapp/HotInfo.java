package com.example.jws.bzapp;

import android.media.Image;

public class HotInfo {
    String Image, Title, Date, Url;

    HotInfo(String Image, String Title, String Date, String Url) {
        this.Image = Image;
        this.Title = Title;
        this.Date = Date;
        this.Url = Url;
    }
}
