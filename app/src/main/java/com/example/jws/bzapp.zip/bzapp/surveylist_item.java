package com.example.jws.bzapp;

public class surveylist_item {

    private String Location;
    private String type;
    private String sales;

    public void setLocation(String Location) {
        this.Location = Location;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setSales(String sales) {
        this.sales = sales;
    }

    public String getLocation() {
        return this.Location;
    }

    public String getType() {
        return this.type;
    }

    public String getSales() {
        return this.sales;
    }

}
