package com.example.jws.bzapp;

public class QuestionInfo {
    String Title, Date, Content;

    QuestionInfo(String Title, String Date, String Content) {
        this.Title = Title;
        this.Date = Date;
        this.Content = Content;
    }
}
