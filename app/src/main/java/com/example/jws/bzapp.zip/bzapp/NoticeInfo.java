package com.example.jws.bzapp;

public class NoticeInfo {
    String Title, Date, Content;

    NoticeInfo(String Title, String Date, String Content) {
        this.Title = Title;
        this.Date = Date;
        this.Content = Content;
    }
}
