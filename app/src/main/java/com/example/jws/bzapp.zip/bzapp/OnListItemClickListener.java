package com.example.jws.bzapp;


interface OnListItemClickListener {
    public void onListItemClick(int position);
}